package ejemplo.aplicacion;

public @interface SpringBootApplication {
}
