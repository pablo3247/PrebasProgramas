public class ConfiguracionSeguridad {
}
